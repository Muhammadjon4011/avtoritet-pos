# AVTORITET POS — Android APK va Windows EXE loyihasi

Bu paket siz yuborgan HTML POS dasturini o‘zgartirmasdan, Android va Windows ilovasi sifatida yig‘ish uchun boshlang‘ich loyiha.

## Muhim
- Bu paket hali tayyor `.apk` yoki `.exe` emas — build qilish uchun loyiha manbalari.
- Dastur ma’lumotlari hozirgi HTML versiyasida qurilmaning lokal xotirasida (`localStorage`) saqlanadi. Android va Windows alohida qurilmalar bo‘lgani uchun ma’lumotlar avtomatik sinxronlashmaydi.
- Dasturdan foydalanishdan oldin Sozlamalar → Ma’lumotlar nusxasi orqali JSON zaxira nusxa olib turing.
- PIN va foydalanuvchi huquqlari HTML ichidagi sinov darajasidagi funksiyalar; ular haqiqiy server xavfsizligi emas.

## 1) Windows EXE yig‘ish
Windows 10/11 kompyuterda:
1. Node.js LTS o‘rnating: https://nodejs.org/
2. Ushbu papkani oching.
3. Papka ichida terminal/PowerShell oching.
4. Quyidagi buyruqlarni bajaring:

```bash
npm install
npm run windows:dev
npm run windows:build
```

O‘rnatish fayli `dist` papkasida hosil bo‘ladi: `AVTORITET-POS-Setup-1.0.0.exe`.

## 2) Android APK yig‘ish
Windows yoki macOS kompyuterda:
1. Node.js LTS va Android Studio o‘rnating.
2. Android Studio orqali Android SDK va kerakli Build Tools komponentlarini o‘rnating.
3. Loyiha papkasida terminal oching:

```bash
npm install
npm run android:init
npm run android:sync
npm run android:open
```

4. Android Studio ochilgach, **Build → Build Bundle(s) / APK(s) → Build APK(s)** ni tanlang.
5. APK odatda `android/app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo‘ladi.

Play Store yoki boshqa qurilmalarga rasmiy tarqatish uchun release signing key bilan alohida imzolash kerak.

## 3) HTML faylni yangilash
Yangi HTML versiya tayyor bo‘lsa, uni `www/index.html` fayli o‘rniga qo‘ying.
- Windows uchun qayta: `npm run windows:build`
- Android uchun: `npm run android:sync`, so‘ng Android Studio'da APK build qiling.

## 4) Kamera va shtrix-kod
HTML ichidagi kamera skaneri `getUserMedia` va `BarcodeDetector` imkoniyatlariga tayanadi. Android qurilmasida kamera ruxsati va WebView qo‘llab-quvvatlashi talab qilinadi; ayrim telefonlarda qo‘lda shtrix-kod kiritish yoki tashqi USB/Bluetooth skaner ishonchliroq bo‘lishi mumkin.
